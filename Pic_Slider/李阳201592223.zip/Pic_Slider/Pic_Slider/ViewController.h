//
//  ViewController.h
//  Pic_Slider
//
//  Created by OurEDA on 2018/3/8.
//  Copyright © 2018年 OurEDA. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

UIScrollView *scrollView;
UIPageControl *pageControl;
